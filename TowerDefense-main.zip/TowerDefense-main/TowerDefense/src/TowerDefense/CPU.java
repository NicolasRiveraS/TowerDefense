package TowerDefense;

class CPU extends Jugador {
    // Atributos

    // Constructor
    public CPU () {
        super();
    }
    
    // Métodos
    public void seleccionarTropasAleatoriamente() {
        
    }
}