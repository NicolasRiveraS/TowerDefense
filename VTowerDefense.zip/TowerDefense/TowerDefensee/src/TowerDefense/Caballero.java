package TowerDefense;

class Caballero extends Tropa {
    // Constructor
    public Caballero() {
        super("Caballero", 100, 15.0, "Arquero","Mago");
    }

    @Override
    public void atacar(Castillo castilloEnemigo) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}

    

